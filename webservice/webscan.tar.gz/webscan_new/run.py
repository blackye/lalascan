#!/usr/bin/env python

from scanui import app
app.run(host='10.220.93.153', port=8080, debug=True)
